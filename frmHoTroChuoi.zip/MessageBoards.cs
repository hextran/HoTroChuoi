﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HoTROchuoi
{
    public partial class MessageBoards : Form
    {
        static TextBox txb1 = new TextBox();
        static TextBox txb22 = new TextBox();
        public MessageBoards()
        {
            InitializeComponent();
        }

        private void MessageBoards_Load(object sender, EventArgs e)
        {
            
            lbl_label.Text = frmHoTroChuoi.contentLabel;
            ModeView md = frmHoTroChuoi.MD;
            if (ModeView.VIEWLISTINFO == md)
            {
                int dem = 0;
                foreach (char c in frmHoTroChuoi.Challenges)
                {
                    dem++;
                    TextBox textboxadd = new TextBox();
                    textboxadd.Text = c + "";
                    textboxadd.Enabled = false;
                    Button btn = new Button();
                    btn.Click += copy;
                    btn.Tag = c.ToString();
                    btn.Text = "Copy (" + dem + ")";
                    flpn.Controls.Add(textboxadd);
                    flpn.Controls.Add(btn);
                }
            } else if(ModeView.VIEWRESULT == md)
            {
                Label lbl = new Label();
                lbl.Text = frmHoTroChuoi.text;
                lbl.AutoSize = true;
                lbl.Dock = DockStyle.Fill;
                flpn.Controls.Add(lbl);
            } else if (ModeView.VIEWLISTINFOSTRING == md)
            {
                int dem = 0;
                foreach (string c in frmHoTroChuoi.Chan)
                {
                    dem++;
                    TextBox textboxadd = new TextBox();
                    textboxadd.Text = c + "";
                    textboxadd.Enabled = false;
                    Button btn = new Button();
                    btn.Click += copy;
                    btn.Tag = c.ToString();
                    btn.Text = "Copy (" + dem + ")";
                    flpn.Controls.Add(textboxadd);
                    flpn.Controls.Add(btn);
                }
            } else if(ModeView.VIEWSETTING == md)
            {
                Label lb1 = new Label();
                lb1.Text = lbl_label.Text;
                lb1.TextAlign = ContentAlignment.TopCenter;
                lb1.AutoSize = true;
                TextBox txb = new TextBox();
                txb.Name = "txb1";
                txb1 = txb;
                Button btn = new Button();
                btn.Text = "Tìm";
                TextBox txb2 = new TextBox();
                txb2.Name = "txb2";
                txb22 = txb2;
                Label lb2 = new Label();
                lb2.Text = frmHoTroChuoi.contentLablel2;
                if (frmHoTroChuoi.function == "findCharCount")
                {
                    btn.Click += findCharCount;
                } else if (frmHoTroChuoi.function == "replacechuoicon")
                {
                    
                    btn.Click += replacechuoicon;
                    btn.Text = "Thay đổi";
                }
                else if(frmHoTroChuoi.function == "splitchar")
                {
                    btn.Click += splitchar;
                    btn.Text = "Tách";
                } else if(frmHoTroChuoi.function == "removechar")
                {
                    btn.Click += removechar;
                    btn.Text = "Xóa chuỗi";
                } else if(frmHoTroChuoi.function == "insertchuoi")
                {
                    btn.Click += insertchuoi;
                    btn.Text = "Chèn";
                }
                
                else {
                    btn.Click += findtext;
                }
                
                flpn.Controls.Add(lb1);
                flpn.Controls.Add(txb);
                if (frmHoTroChuoi.function == "replacechuoicon")
                {
                    flpn.Controls.Add(lb2);
                    flpn.Controls.Add(txb22);
                } else if(frmHoTroChuoi.function == "insertchuoi")
                {
                    flpn.Controls.Add(lb2);
                    flpn.Controls.Add(txb22);
                }
                flpn.Controls.Add(btn);
            }
        }

        private void insertchuoi(object sender, EventArgs e)
        {
            frmHoTroChuoi.text = frmHoTroChuoi.text.Insert(int.Parse(txb1.Text), txb22.Text);
            DialogResult = DialogResult.OK;
            frmHoTroChuoi.MD = ModeView.VIEWRESULT;
            this.Close();
        }

        private void removechar(object sender, EventArgs e)
        {
            frmHoTroChuoi.session = txb1.Text;
            frmHoTroChuoi.location = frmHoTroChuoi.text.IndexOf(txb1.Text);
            frmHoTroChuoi.text = frmHoTroChuoi.text.Replace(txb1.Text,"");
            DialogResult = DialogResult.OK;
            frmHoTroChuoi.MD = ModeView.VIEWRESULT;
            this.Close();
        }

        private void replacechuoicon(object sender, EventArgs e)
        {
            frmHoTroChuoi.session = txb1.Text;
            frmHoTroChuoi.location = frmHoTroChuoi.text.IndexOf(txb1.Text);
            if (frmHoTroChuoi.location != -1)
            {
                frmHoTroChuoi.text = frmHoTroChuoi.text.Replace(txb1.Text, txb22.Text);
            }
            DialogResult = DialogResult.OK;
            frmHoTroChuoi.MD = ModeView.VIEWRESULT;
            this.Close();
        }

            private void splitchar(object sender, EventArgs e)
        {
            frmHoTroChuoi.session = txb1.Text;
            frmHoTroChuoi.location = frmHoTroChuoi.text.IndexOf(txb1.Text);
            if (frmHoTroChuoi.location != -1)
            {
                
                string[] vs = frmHoTroChuoi.text.Split(frmHoTroChuoi.session);
                frmHoTroChuoi.Chan = vs.ToList();
            }
            DialogResult = DialogResult.OK;
            frmHoTroChuoi.MD = ModeView.VIEWLISTINFOSTRING;
            this.Close();
        }
        private void findtext(object sender, EventArgs e)
        {
            frmHoTroChuoi.session = txb1.Text;
            if (frmHoTroChuoi.last == "true")
            {
                frmHoTroChuoi.location = frmHoTroChuoi.text.LastIndexOf(txb1.Text);
            } else
            {
                frmHoTroChuoi.location = frmHoTroChuoi.text.IndexOf(txb1.Text);
            }
            
            if(frmHoTroChuoi.location != -1)
            {
                
                string ktcuoi = frmHoTroChuoi.session[frmHoTroChuoi.session.Length - 1].ToString();


                int dmz = 0;
                for (int i = frmHoTroChuoi.location; i < frmHoTroChuoi.text.Length + 1; i++)
                {
                    try
                    {

                        if (dmz == frmHoTroChuoi.session.Length)
                        {
                            frmHoTroChuoi.endlocation = i - 1;
                            break;
                        }
                        dmz++;

                    }
                    catch
                    {
                        MessageBox.Show(i.ToString());
                    }

                }

                
            }

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void findCharCount(object sender, EventArgs e)
        {
            
            frmHoTroChuoi.session = txb1.Text;
            frmHoTroChuoi.location = frmHoTroChuoi.text.IndexOf(txb1.Text);
            if(frmHoTroChuoi.location != -1)
            {
                int dem = 0;
                int la = frmHoTroChuoi.text.IndexOf(txb1.Text);
                string s = frmHoTroChuoi.text;
                while(la != -1)
                {
                    int num = la + frmHoTroChuoi.session.Length + 1;
                    frmHoTroChuoi.Chan.Add(la + "=>" + num);
                    dem++;
                    s = s.Substring(la + frmHoTroChuoi.session.Length);
                    
                    la = s.IndexOf(txb1.Text);
                    

                }
                frmHoTroChuoi.location = dem;
            }
            DialogResult = DialogResult.OK;
            frmHoTroChuoi.MD = ModeView.VIEWLISTINFOSTRING;
            this.Close();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void copy (object sender, EventArgs e)
        {
            Button btn = sender as Button;
            Clipboard.SetText(btn.Tag.ToString());
            MessageBox.Show("Copy thành công!", "Trạng Thái");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void flpn_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
