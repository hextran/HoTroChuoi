﻿namespace HoTROchuoi
{
    public partial class frmHoTroChuoi : Form
    {
        public static ModeView MD = ModeView.VIEWRESULT;
        public static List<char> Challenges = new List<char>();
        public static List<string> Chan = new List<string>();
        public static string text = "";
        public static string contentLabel = "";
        public static int location = 0;
        public static string session = "";
        public static int endlocation = 0;
        public static string last = "no";
        public static string function = "";
        public static string contentLablel2 = "";
        public frmHoTroChuoi()
        {
            InitializeComponent();
        }
        
        private void btnCount_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtGoc.Text.Length + "";
            text = "";
            int dem = 0;
            foreach (char c in txtGoc.Text)
            {
                dem++;
                text += "[" + dem + "]" + c.ToString();
            }
            MD = ModeView.VIEWRESULT;
            contentLabel = "Số kí tự trong chuỗi được điếm:";
        }

        private void btnUpper_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtGoc.Text.ToUpper();
            text = txtResult.Text;
            int dem = 0;
            foreach (char c in txtResult.Text)
            {
                dem++;
                text += "[" + dem + "]" + c.ToString();
            }
            MD = ModeView.VIEWRESULT;
            contentLabel = "Kí tự được viết hoa:";
        }

        private void btnLower_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtGoc.Text.ToLower();
            text = txtResult.Text;

            int dem = 0;
            foreach (char c in txtResult.Text)
            {
                dem++;
                text += "[" + dem + "]" + c.ToString();
            }
            MD = ModeView.VIEWRESULT;
            contentLabel = "Kí tự được viết thường:";
        }

        private void btnCountUpper_Click(object sender, EventArgs e)
        {
            char[] listchar = txtGoc.Text.ToCharArray();
            Challenges.Clear();
            int stt = 0;
            foreach (char c in listchar)
            {
                if (char.IsUpper(c))
                {
                    Challenges.Add(c);
                    stt++;
                }
            }
            txtResult.Text = "Có "+ stt + " số kí tự in hoa";
            MD = ModeView.VIEWLISTINFO;
            contentLabel = "Số kí tự được viết hoa:";
        }

        private void btnCountLower_Click(object sender, EventArgs e)
        {
            int dem = 0;
            Challenges.Clear();
            foreach (char c in txtGoc.Text)
            {
                if (char.IsLower(c))
                {
                    Challenges.Add(c);
                    dem++;
                }
            }
            txtResult.Text = dem + "";
            MD = ModeView.VIEWLISTINFO;
            contentLabel = "Số kí tự được viết thường:";
        }

        private void btnCountIsNumberic_Click(object sender, EventArgs e)
        {
            int dem = 0;
            Challenges.Clear();
            foreach (char c in txtGoc.Text)
            {
                if (char.IsDigit(c))
                {
                    Challenges.Add(c);
                    dem++;
                }
            }
            txtResult.Text = dem + "";
            MD = ModeView.VIEWLISTINFO;
            contentLabel = "Số kí tự được viết bằng số:";
        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text;
        }

        private void frmHoTroChuoi_Load(object sender, EventArgs e)
        {

        }

        private void txtResult_DoubleClick(object sender, EventArgs e)
        {
            MessageBoards frmOpen = new MessageBoards();
            frmOpen.Show();
        }

        private void btnReverse_Click(object sender, EventArgs e)
        {
            txtResult.Text = "";
            Challenges = txtGoc.Text.Reverse().ToList();
            foreach (char i in Challenges)
            {
                txtResult.Text += i;
            }
            MD = ModeView.VIEWLISTINFO;
            contentLabel = "Kí tự được làm ngược:";
        }

        private void btnMaxString_Click(object sender, EventArgs e)
        {
            Chan.Clear();
            string stext = txtGoc.Text.Trim();
            string[] s2text = stext.Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);
            txtResult.Text = "";
            foreach (string c in s2text)
            {
                char[] arrCh = c.ToCharArray();
                for(int i = 0; i < arrCh.Length; i++)
                {
                    arrCh[i] = char.ToLower(arrCh[i]);
                }
                arrCh[0] = char.ToUpper(arrCh[0]);
                string text = "";
                foreach (char ch in arrCh)
                {
                    text += Convert.ToString(ch);
                }
                Chan.Add(text);
                text += " ";
                txtResult.Text += text;
            }
            MD = ModeView.VIEWLISTINFOSTRING;
            contentLabel = "Từ được làm tối ưu";
        }

        private void btnFindStart_Click(object sender, EventArgs e)
        {
            last = "no";
            MD = ModeView.VIEWSETTING;
            MessageBoards pan = new MessageBoards();
            contentLabel = "Tìm vị trí đầu:";
            function = "txtFind";
            text = txtGoc.Text;
            if(pan.ShowDialog() == DialogResult.OK)
            {
                if(location == -1)
                {
                    txtResult.Text = "Không tìm thấy kí tự [" + session + "]";
                    
                } else
                {
                    txtResult.Text = "Tìm thấy [" + session + "] ở vị trí [" + location + "] và kết thúc ở [" + endlocation + "]";
                }
                
            }
        }

        private void btnFindEnd_Click(object sender, EventArgs e)
        {
            last = "true";
            MD = ModeView.VIEWSETTING;
            MessageBoards pan = new MessageBoards();
            contentLabel = "Tìm vị trí cuối:";
            function = "txtFind";
            text = txtGoc.Text;
            if (pan.ShowDialog() == DialogResult.OK)
            {
                if (location == -1)
                {
                    txtResult.Text = "Không tìm thấy kí tự [" + session + "]";

                }
                else
                {
                    txtResult.Text = "Tìm thấy [" + session + "] ở vị trí [" + location + "] và kết thúc ở [" + endlocation + "]";
                }

            }
        }

        private void btnFindCharLocation_Click(object sender, EventArgs e)
        {
            MD = ModeView.VIEWSETTING;
            MessageBoards pan = new MessageBoards();
            contentLabel = "Nhập kí tự muốn điếm: ";
            function = "findCharCount";
            text = txtGoc.Text;
            Chan.Clear();
            if(pan.ShowDialog() == DialogResult.OK)
            {
                if (location == -1)
                {
                    txtResult.Text = "Không tìm thấy kí tự [" + session + "]";

                }
                else
                {
                   txtResult.Text = "Tìm thấy [" + session + "] xuất hiện [" + location + "] lần!";
                }
            }
        }

        private void btnSplitChar_Click(object sender, EventArgs e)
        {
            MD = ModeView.VIEWSETTING;
            MessageBoards pan = new MessageBoards();
            contentLabel = "Nhập kí muốn tách: ";
            function = "splitchar";
            text = txtGoc.Text;
            Chan.Clear();
            if (pan.ShowDialog() == DialogResult.OK)
            {
                if (location == -1)
                {
                    txtResult.Text = "Không tìm thấy kí tự [" + session + "]";

                }
                else
                {
                    txtResult.Text = "Nhấn vào đây 2 lần để xem chi tiết!\r\n";
                    foreach (string v in Chan)
                    {
                        txtResult.Text += v + "\r\n";
                    }
                   // txtResult.Text = "Tìm thấy [" + session + "] xuất hiện [" + location + "] lần!";
                }
            }
        }

        private void btnChangeChar_Click(object sender, EventArgs e)
        {
            MD = ModeView.VIEWSETTING;
            MessageBoards pan = new MessageBoards();
            contentLabel = "Nhập kí gốc: ";
            contentLablel2 = "Nhập kí tự muốn thay đổi: ";
            function = "replacechuoicon";
            text = txtGoc.Text;
            Chan.Clear();
            if (pan.ShowDialog() == DialogResult.OK)
            {
                if (location == -1)
                {
                    txtResult.Text = "Không tìm thấy kí tự [" + session + "] để thay đổi";

                }
                else
                {
                    txtResult.Text = text;
                }
            }
        }

        private void btnRemoveChar_Click(object sender, EventArgs e)
        {
            MD = ModeView.VIEWSETTING;
            MessageBoards pan = new MessageBoards();
            contentLabel = "Nhập chữ muốn xóa: ";
            function = "removechar";
            text = txtGoc.Text;
      
            if (pan.ShowDialog() == DialogResult.OK)
            {
                txtResult.Text = text;
            }
            MD = ModeView.VIEWRESULT;
        }

        private void btnADDChar_Click(object sender, EventArgs e)
        {
            MD = ModeView.VIEWSETTING;
            MessageBoards pan = new MessageBoards();
            contentLabel = "Nhập vị trí chèn: ";
            contentLablel2 = "Nhập chuỗi muốn chèn: ";
            function = "insertchuoi";
            text = txtGoc.Text;

            if (pan.ShowDialog() == DialogResult.OK)
            {
                txtResult.Text = text;
            }
            MD = ModeView.VIEWRESULT;
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {

        }

        private void frmHoTroChuoi_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn chắc có muốn thoát không?", "Hỏi thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            e.Cancel = (result == DialogResult.No);
        }
    }
}