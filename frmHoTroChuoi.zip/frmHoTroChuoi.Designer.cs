﻿namespace HoTROchuoi
{
    partial class frmHoTroChuoi
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtGoc = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnMaxString = new System.Windows.Forms.Button();
            this.btnCountIsNumberic = new System.Windows.Forms.Button();
            this.btnCountLower = new System.Windows.Forms.Button();
            this.btnReverse = new System.Windows.Forms.Button();
            this.btnLower = new System.Windows.Forms.Button();
            this.btnCountUpper = new System.Windows.Forms.Button();
            this.btnUpper = new System.Windows.Forms.Button();
            this.btnCount = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnADDChar = new System.Windows.Forms.Button();
            this.btnChangeChar = new System.Windows.Forms.Button();
            this.btnSplitChar = new System.Windows.Forms.Button();
            this.btnRemoveChar = new System.Windows.Forms.Button();
            this.btnFindCharLocation = new System.Windows.Forms.Button();
            this.btnFindEnd = new System.Windows.Forms.Button();
            this.btnFindStart = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtGoc);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 119);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Văn bản:";
            // 
            // txtGoc
            // 
            this.txtGoc.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtGoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGoc.Location = new System.Drawing.Point(3, 19);
            this.txtGoc.Multiline = true;
            this.txtGoc.Name = "txtGoc";
            this.txtGoc.Size = new System.Drawing.Size(194, 97);
            this.txtGoc.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtResult);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(218, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(266, 119);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kết quả:";
            // 
            // txtResult
            // 
            this.txtResult.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResult.Location = new System.Drawing.Point(3, 19);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(260, 97);
            this.txtResult.TabIndex = 0;
            this.txtResult.TextChanged += new System.EventHandler(this.txtResult_TextChanged);
            this.txtResult.DoubleClick += new System.EventHandler(this.txtResult_DoubleClick);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox3.Controls.Add(this.btnMaxString);
            this.groupBox3.Controls.Add(this.btnCountIsNumberic);
            this.groupBox3.Controls.Add(this.btnCountLower);
            this.groupBox3.Controls.Add(this.btnReverse);
            this.groupBox3.Controls.Add(this.btnLower);
            this.groupBox3.Controls.Add(this.btnCountUpper);
            this.groupBox3.Controls.Add(this.btnUpper);
            this.groupBox3.Controls.Add(this.btnCount);
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox3.Location = new System.Drawing.Point(12, 137);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(472, 116);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Chức năng cơ bản:";
            // 
            // btnMaxString
            // 
            this.btnMaxString.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnMaxString.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMaxString.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMaxString.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnMaxString.Location = new System.Drawing.Point(171, 80);
            this.btnMaxString.Name = "btnMaxString";
            this.btnMaxString.Size = new System.Drawing.Size(159, 23);
            this.btnMaxString.TabIndex = 0;
            this.btnMaxString.Text = "Tối ưu chuỗi";
            this.btnMaxString.UseVisualStyleBackColor = false;
            this.btnMaxString.Click += new System.EventHandler(this.btnMaxString_Click);
            // 
            // btnCountIsNumberic
            // 
            this.btnCountIsNumberic.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnCountIsNumberic.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCountIsNumberic.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCountIsNumberic.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCountIsNumberic.Location = new System.Drawing.Point(336, 51);
            this.btnCountIsNumberic.Name = "btnCountIsNumberic";
            this.btnCountIsNumberic.Size = new System.Drawing.Size(130, 23);
            this.btnCountIsNumberic.TabIndex = 0;
            this.btnCountIsNumberic.Text = "Điếm ký tự là số";
            this.btnCountIsNumberic.UseVisualStyleBackColor = false;
            this.btnCountIsNumberic.Click += new System.EventHandler(this.btnCountIsNumberic_Click);
            // 
            // btnCountLower
            // 
            this.btnCountLower.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnCountLower.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCountLower.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCountLower.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCountLower.Location = new System.Drawing.Point(171, 51);
            this.btnCountLower.Name = "btnCountLower";
            this.btnCountLower.Size = new System.Drawing.Size(159, 23);
            this.btnCountLower.TabIndex = 0;
            this.btnCountLower.Text = "Điếm số ký tự in thường";
            this.btnCountLower.UseVisualStyleBackColor = false;
            this.btnCountLower.Click += new System.EventHandler(this.btnCountLower_Click);
            // 
            // btnReverse
            // 
            this.btnReverse.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnReverse.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReverse.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnReverse.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReverse.Location = new System.Drawing.Point(6, 80);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(159, 23);
            this.btnReverse.TabIndex = 0;
            this.btnReverse.Text = "Đảo chuỗi";
            this.btnReverse.UseVisualStyleBackColor = false;
            this.btnReverse.Click += new System.EventHandler(this.btnReverse_Click);
            // 
            // btnLower
            // 
            this.btnLower.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnLower.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLower.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLower.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLower.Location = new System.Drawing.Point(336, 22);
            this.btnLower.Name = "btnLower";
            this.btnLower.Size = new System.Drawing.Size(130, 23);
            this.btnLower.TabIndex = 0;
            this.btnLower.Text = "In chữ thường";
            this.btnLower.UseVisualStyleBackColor = false;
            this.btnLower.Click += new System.EventHandler(this.btnLower_Click);
            // 
            // btnCountUpper
            // 
            this.btnCountUpper.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnCountUpper.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCountUpper.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCountUpper.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCountUpper.Location = new System.Drawing.Point(6, 51);
            this.btnCountUpper.Name = "btnCountUpper";
            this.btnCountUpper.Size = new System.Drawing.Size(159, 23);
            this.btnCountUpper.TabIndex = 0;
            this.btnCountUpper.Text = "Điếm số ký tự in hoa";
            this.btnCountUpper.UseVisualStyleBackColor = false;
            this.btnCountUpper.Click += new System.EventHandler(this.btnCountUpper_Click);
            // 
            // btnUpper
            // 
            this.btnUpper.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnUpper.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpper.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpper.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpper.Location = new System.Drawing.Point(171, 22);
            this.btnUpper.Name = "btnUpper";
            this.btnUpper.Size = new System.Drawing.Size(159, 23);
            this.btnUpper.TabIndex = 0;
            this.btnUpper.Text = "In chữ hoa";
            this.btnUpper.UseVisualStyleBackColor = false;
            this.btnUpper.Click += new System.EventHandler(this.btnUpper_Click);
            // 
            // btnCount
            // 
            this.btnCount.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnCount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCount.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCount.Location = new System.Drawing.Point(6, 22);
            this.btnCount.Name = "btnCount";
            this.btnCount.Size = new System.Drawing.Size(159, 23);
            this.btnCount.TabIndex = 0;
            this.btnCount.Text = "Số ký tự trong chuỗi";
            this.btnCount.UseVisualStyleBackColor = false;
            this.btnCount.Click += new System.EventHandler(this.btnCount_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.btnADDChar);
            this.groupBox4.Controls.Add(this.btnChangeChar);
            this.groupBox4.Controls.Add(this.btnSplitChar);
            this.groupBox4.Controls.Add(this.btnRemoveChar);
            this.groupBox4.Controls.Add(this.btnFindCharLocation);
            this.groupBox4.Controls.Add(this.btnFindEnd);
            this.groupBox4.Controls.Add(this.btnFindStart);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(12, 259);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(472, 115);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Chức năng nâng cao:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(243, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Cre by HexTran";
            // 
            // btnADDChar
            // 
            this.btnADDChar.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnADDChar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnADDChar.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnADDChar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnADDChar.Location = new System.Drawing.Point(112, 80);
            this.btnADDChar.Name = "btnADDChar";
            this.btnADDChar.Size = new System.Drawing.Size(88, 23);
            this.btnADDChar.TabIndex = 1;
            this.btnADDChar.Text = "Chèn chuỗi";
            this.btnADDChar.UseVisualStyleBackColor = false;
            this.btnADDChar.Click += new System.EventHandler(this.btnADDChar_Click);
            // 
            // btnChangeChar
            // 
            this.btnChangeChar.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnChangeChar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnChangeChar.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnChangeChar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnChangeChar.Location = new System.Drawing.Point(235, 51);
            this.btnChangeChar.Name = "btnChangeChar";
            this.btnChangeChar.Size = new System.Drawing.Size(141, 23);
            this.btnChangeChar.TabIndex = 2;
            this.btnChangeChar.Text = "Thay đổi chuỗi con";
            this.btnChangeChar.UseVisualStyleBackColor = false;
            this.btnChangeChar.Click += new System.EventHandler(this.btnChangeChar_Click);
            // 
            // btnSplitChar
            // 
            this.btnSplitChar.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnSplitChar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSplitChar.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSplitChar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSplitChar.Location = new System.Drawing.Point(148, 51);
            this.btnSplitChar.Name = "btnSplitChar";
            this.btnSplitChar.Size = new System.Drawing.Size(81, 23);
            this.btnSplitChar.TabIndex = 3;
            this.btnSplitChar.Text = "Tách từ";
            this.btnSplitChar.UseVisualStyleBackColor = false;
            this.btnSplitChar.Click += new System.EventHandler(this.btnSplitChar_Click);
            // 
            // btnRemoveChar
            // 
            this.btnRemoveChar.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnRemoveChar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRemoveChar.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRemoveChar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRemoveChar.Location = new System.Drawing.Point(6, 80);
            this.btnRemoveChar.Name = "btnRemoveChar";
            this.btnRemoveChar.Size = new System.Drawing.Size(100, 23);
            this.btnRemoveChar.TabIndex = 4;
            this.btnRemoveChar.Text = "Xóa chuỗi con";
            this.btnRemoveChar.UseVisualStyleBackColor = false;
            this.btnRemoveChar.Click += new System.EventHandler(this.btnRemoveChar_Click);
            // 
            // btnFindCharLocation
            // 
            this.btnFindCharLocation.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnFindCharLocation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFindCharLocation.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnFindCharLocation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFindCharLocation.Location = new System.Drawing.Point(6, 51);
            this.btnFindCharLocation.Name = "btnFindCharLocation";
            this.btnFindCharLocation.Size = new System.Drawing.Size(136, 23);
            this.btnFindCharLocation.TabIndex = 6;
            this.btnFindCharLocation.Text = "Điếm số lần xuất hiện";
            this.btnFindCharLocation.UseVisualStyleBackColor = false;
            this.btnFindCharLocation.Click += new System.EventHandler(this.btnFindCharLocation_Click);
            // 
            // btnFindEnd
            // 
            this.btnFindEnd.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnFindEnd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFindEnd.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnFindEnd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFindEnd.Location = new System.Drawing.Point(171, 22);
            this.btnFindEnd.Name = "btnFindEnd";
            this.btnFindEnd.Size = new System.Drawing.Size(205, 23);
            this.btnFindEnd.TabIndex = 7;
            this.btnFindEnd.Text = "Tìm vị trí xuất hiện cuối cùng";
            this.btnFindEnd.UseVisualStyleBackColor = false;
            this.btnFindEnd.Click += new System.EventHandler(this.btnFindEnd_Click);
            // 
            // btnFindStart
            // 
            this.btnFindStart.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnFindStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFindStart.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnFindStart.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFindStart.Location = new System.Drawing.Point(6, 22);
            this.btnFindStart.Name = "btnFindStart";
            this.btnFindStart.Size = new System.Drawing.Size(159, 23);
            this.btnFindStart.TabIndex = 8;
            this.btnFindStart.Text = "Tìm vị trí xuất hiện đầu tiên";
            this.btnFindStart.UseVisualStyleBackColor = false;
            this.btnFindStart.Click += new System.EventHandler(this.btnFindStart_Click);
            // 
            // frmHoTroChuoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(496, 385);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmHoTroChuoi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hỗ trợ chuỗi";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmHoTroChuoi_FormClosing);
            this.Load += new System.EventHandler(this.frmHoTroChuoi_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private TextBox txtGoc;
        private TextBox txtResult;
        private Button btnMaxString;
        private Button btnCountIsNumberic;
        private Button btnCountLower;
        private Button btnReverse;
        private Button btnLower;
        private Button btnCountUpper;
        private Button btnUpper;
        private Button btnCount;
        private Label label1;
        private Button btnADDChar;
        private Button btnChangeChar;
        private Button btnSplitChar;
        private Button btnRemoveChar;
        private Button btnFindCharLocation;
        private Button btnFindEnd;
        private Button btnFindStart;
    }
}