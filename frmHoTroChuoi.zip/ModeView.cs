﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HoTROchuoi
{
    public enum ModeView
    {
        VIEWLISTINFO,
        VIEWSETTING,
        VIEWRESULT,
        VIEWLISTINFOSTRING
    }
}
